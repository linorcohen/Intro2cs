#################################################################
# FILE : additional_file.py
# WRITER : Linor Cohen , linorcohen , 318861226
# EXERCISE : intro2cse ex1 2021
# DESCRIPTION: A simple program that prints the secret function.
# STUDENTS I DISCUSSED THE EXERCISE WITH: NONE
# WEB PAGES I USED: NONE
# NOTES: NONE
#################################################################

def secret_function():
    """
    This function prints a string.
    """
    print("I (username 'linorcohen') have read the submission"
          " response and know not to copy.")
