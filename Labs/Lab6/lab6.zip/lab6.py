#################################################################
# FILE : lab6.py
# WRITER : Linor Cohen , linorcohen , 318861226
# EXERCISE : intro2cse lab6 2021
# DESCRIPTION: lab6
# STUDENTS I DISCUSSED THE EXERCISE WITH: NONE
# WEB PAGES I USED: NONE
# NOTES: NONE
#################################################################


def user_input():
    num = input()
    while num != '7':
        num = input()
    print('Done.')


if __name__ == '__main__':
    user_input()
