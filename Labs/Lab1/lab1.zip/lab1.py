#############################################################
# FILE: lab1.py
# WRITER : Linor Cohen , linorcohen , 318861226
# EXERCISE : intro2cs2 lab1 2021
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################
print("Hello World!")
